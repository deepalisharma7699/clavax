# For Database : Please Import Dump.sql in database
# Step to Create Connection :
# Open : assignment->config->database.php
# search for $db_host, $db_name, $db_pwd and assign the respective value to these variables.

<!DOCTYPE html>
<html lang="en">
<head>
  <title>User Form</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="https://cdn.ckeditor.com/ckeditor5/27.1.0/classic/ckeditor.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" />
  
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css" crossorigin="anonymous" />

  <style>
    .refresh{
        background-color: #969696;
        padding: 15px;
        font-size: 18px;
        color: white;
        margin: 0px 10px;
        height: 50px;
        width: 50px;
        border-radius: 5px;
    }
  </style>
</head>

<body>

<div class="container">
<div class="card" style="padding-top:30px">
    <div class="row">
        <div class="col-md-6"><h2>Students Details</h2></div>
        <div class="col-md-6" style="text-align:right;"><a href="<?php echo base_url(); ?>web/student_form" class="btn btn-info">Add Student</a></div>
    </div>
    <div class="row" style="padding-top:30px">
        <table id="example" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>Sr. No.</th>
                    <th>Student Name </th>
                    <th>Father’s Name</th>
                    <th>DOB</th>                   
                    <th>Address</th>
                    <th>City</th>
                    <th>State</th> 
                    <th>Pin</th>
                    <th>Phone No.</th>
                    <th>Email</th>
                    <th>Marks </th>
                    <th>Enrolled Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php
            if(!empty($data)){
                for($i=0;$i<count($data);$i++){
                    $Dataarr=$data[$i];
                    // print_r($Dataarr);
                    
            ?>
                <tr>
                    <td><?= ($i+1); ?></td>
                    <td><?= $Dataarr['studentName'];?></td>
                    <td><?= $Dataarr['fatherName'];?></td>
                    <td><?= $Dataarr['dob'];?></td>
                    <td><?= $Dataarr['address'];?></td>
                    <td><?= $Dataarr['city'];?></td>
                    <td><?= $Dataarr['state'];?></td>
                    <td><?= $Dataarr['pincode'];?></td>
                    <td><?= $Dataarr['contactNo'];?></td>
                    <td><?= $Dataarr['email'];?></td>
                    <td><?= $Dataarr['marks'];?></td>
                    <td><?= $Dataarr['enrollDate'];?></td>
                    <td><a class="btn btn-info" href="<?php echo base_url(); ?>web/student_form/<?= $Dataarr['autoId']; ?>">edit</a></td>
                </tr>
                <?php }
                }?>
            </tbody>
        </table>
    </div>
    </div>
</div>
</body>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css" />
<script type="text/javascript" src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready( function () {
    $('#example').DataTable();
} );
</script>

</html>

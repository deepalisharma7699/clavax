<!DOCTYPE html>
<html lang="en">
<head>
  <title>Student Form</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="https://cdn.ckeditor.com/ckeditor5/27.1.0/classic/ckeditor.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" />
  <script src="<?=base_url() ?>assets/js/student.js"></script>
  <style>
    .refresh{
        background-color: #969696;
        padding: 15px;
        font-size: 18px;
        color: white;
        margin: 0px 10px;
        height: 50px;
        width: 50px;
        border-radius: 5px;
    }
  </style>
</head>
<body>

<div class="container">
<?php 
// print_r($data);
// die;
?>
  <input type="hidden" id="base_url" value="<?=base_url(); ?>">
  <h2><?php echo(!isset($data['autoId']))?"Add New" : 'Update'; ?> Student Detail: </h2>
  <form id="user_form" autocomplete="on" action="#">
  <input type="hidden" name="studentId" value="<?php echo(!empty($data['autoId']))?$data['autoId'] : ''; ?>">
    <div class="form-group">
      <label for="name">Student Name:</label>
      <input type="text" class="form-control" id="name" placeholder="Enter name" name="name" value="<?php echo(!empty($data['studentName']))?$data['studentName'] : ""; ?>">
      <span id="nameError" style="color: red;"></span>
    </div>
    <div class="form-group">
      <label for="fname">Father Name:</label>
      <input type="text" class="form-control" id="fname" placeholder="Enter father name" name="fname"  value="<?php echo(!empty($data['fatherName']))?$data['fatherName'] : ""; ?>">
      <span id="fnameError" style="color: red;"></span>
    </div> 
    
    <div class="form-group">
       <label for="dob">Date Of Birth:</label>
       <input type="text" id="dob" name="dob" size="20" class="form-control input" placeholder="mm/dd/yyyy"  value="<?php echo(!empty($data['dob']))?$data['dob'] : ""; ?>"/>
       <span id="dobError" style="color: red;"></span>
    </div>
    <div class="form-group">
      <label for="editor">Address:</label>
      <input type="text" id="address" name="address" class="form-control input" placeholder="Enter address"  value="<?php echo(!empty($data['address']))?$data['address'] : ""; ?>"/>
     
      <span id="editorError" style="color: red;"></span>
    </div>
    <div class="form-group">
       <label for="city">City:</label>
       <input type="text" id="city" name="city" class="form-control input" placeholder="Enter city"  value="<?php echo(!empty($data['city']))?$data['city'] : ""; ?>"/>
       <span id="cityError" style="color: red;"></span>
    </div>
    <div class="form-group">
       <label for="state">State:</label>
       <input type="text" id="state" name="state" class="form-control input" placeholder="Enter State"  value="<?php echo(!empty($data['state']))?$data['state'] : ""; ?>"/>
       <span id="stateError" style="color: red;"></span>
    </div>
    <div class="form-group">
       <label for="pin">Pincode:</label>
       <input type="text" id="pin" name="pin" class="form-control input" placeholder="Enter pincode"  value="<?php echo(!empty($data['pincode']))?$data['pincode'] : ""; ?>"/>
       <span id="pinError" style="color: red;"></span>
    </div>
    <div class="form-group">
       <label for="phone">Phone No:</label>
       <input type="text" id="phone" name="phone" class="form-control input" placeholder="Enter phone number"  value="<?php echo(!empty($data['contactNo']))?$data['contactNo'] : ""; ?>"/>
       <span id="phoneError" style="color: red;"></span>
    </div>
    <div class="form-group">
       <label for="email">Email:</label>
       <input type="email" id="email" name="email" class="form-control input" placeholder="Enter email"  value="<?php echo(!empty($data['email']))?$data['email'] : ""; ?>"/>
       <span id="emailError" style="color: red;"></span>
    </div>
    <div class="form-group">
       <label for="class">Class:</label>
       <select name="class" id="class" class="form-control">
       <option selected="true" disabled="true" value="">Select Class</option>
       <?php
             $data['class'] = empty($data['class'])?'':$data['class'];
            for($i=5;$i<=10;$i++){
               $sel = ($data['class']==$i)?'selected':'';
               echo "<option ".$sel." value='".$i."'>".$i."th Class</option>";
            }
       ?>
            <!-- <option value="5">5th Class</option>
            <option value="6">6th Class</option>           
            <option value="7">7th Class</option>
            <option value="8">8th Class</option>
            <option value="9">9th Class</option>
            <option value="10">10th Class</option> -->
        </select>
       <span id="classError" style="color: red;"></span>

    </div>   
    <div class="form-group">
       <label for="marks">Marks(%):</label>
       <input type="text" id="marks" name="marks" class="form-control input" placeholder="Enter marks"  value="<?php echo(!empty($data['marks']))?$data['marks'] : ""; ?>"/>
       <span id="marksError" style="color: red;"></span>
    </div>
    <div class="form-group" style="text-align: center">
    <?php $btntxt= (!isset($data['autoId']))?"Submit" : 'Update'; ?>
        <button type="button" onclick="validate();" id="submit" class="btn btn-primary"><?= $btntxt ?></button>
    </div>
  </form>
</div>
</body>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css" />
</html>

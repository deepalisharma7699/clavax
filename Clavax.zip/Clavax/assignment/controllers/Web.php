<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web extends CI_Controller {
	public function index()
	{
		$this->load->model('StudentModel');
		$result['data'] = array();
		$response = $this->StudentModel->getallstudentdetails();
		if($response['success']==1){
			$result['data']=$response['data'];
		}
		$this->load->view('student_details',$result);
	}

	public function form_submit(){	
		$this->load->model('StudentModel');
		$data = $_POST;
		if(empty($data['studentId'])){
			// create new student
			$response = $this->StudentModel->insertstudentdetails($data);
		}else{
			// update existing student
			$response = $this->StudentModel->updatestudentdetails($data);
		}
		header("Content-type: application/json");
		echo json_encode($response);
	}

	public function student_form($student_id='')
	{
		$this->load->model('StudentModel');	
		$response = $this->StudentModel->getdetailofstudent($student_id);	
		$result['data']=[];
		if($response['success']==1){
           $result['data']=$response['data'][0];
		}	
		$this->load->view('student_form',$result);
	}
	

}

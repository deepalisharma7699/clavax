<?php
class StudentModel extends CI_Model
{
    public function __construct() {
        parent::__construct();
        $this->db = $this->load->database('default', true);
    }
function getallstudentdetails(){
    try {     
        $query = "SELECT autoId,studentName, fatherName, date_format(dob,'%d-%b-%Y') as dob, address, city, state, pincode, contactNo, email, class, marks,date_format(enrollDate,'%d-%b-%Y %h:%i %p') as enrollDate FROM tbl_student_master";
        $stmt = $this->db->conn_id->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if ($result) { 
            $response['success'] = 1;
            $response["data"] = $result;
        } else {
            $response['success'] = 0;
            $response["message"] = "No data found";
        }
    } catch (Exception $ex) {
        $response['success'] = 0;
        $response['message'] = $ex->getMessage();
    }       
    return $response;
}
function getdetailofstudent($student_id){
    try {     
        $query = "SELECT autoId,studentName, fatherName, dob, address, city, state, pincode, contactNo, email, class, marks,enroll_date FROM tbl_student_master where autoId={$student_id}";
        $stmt = $this->db->conn_id->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if ($result) { 
            $response['success'] = 1;
            $response["data"] = $result;
        } else {
            $response['success'] = 0;
            $response["message"] = "No data found";
        }
    } catch (Exception $ex) {
        $response['success'] = 0;
        $response['message'] = $ex->getMessage();
    }       
    return $response;
}

    function insertstudentdetails($data){
        try {    
            $enrolldate = date('Y-m-d H:i:s'); 
            $query = "INSERT INTO `tbl_student_master`(`studentName`,`fatherName`,`dob`,`address`,`city`,`state`,`pincode`,`contactNo`,`email`,`class`,`marks`,`enrollDate`)VALUES(:studentName,:fatherName,:dob,:address,:city,:state,:pincode,:contactNo,:email,:class,:marks,:enrolldate)";
            $stmt = $this->db->conn_id->prepare($query);
            $stmt->bindParam(':studentName', $data['name'], PDO::PARAM_STR);
            $stmt->bindParam(':fatherName', $data['fname'], PDO::PARAM_STR);            
            $stmt->bindParam(':dob', $data['dob'], PDO::PARAM_STR); 
            $stmt->bindParam(':address', $data['address'], PDO::PARAM_STR);
            $stmt->bindParam(':city', $data['city'], PDO::PARAM_STR);
            $stmt->bindParam(':state', $data['state'], PDO::PARAM_STR);
            $stmt->bindParam(':pincode', $data['pin'], PDO::PARAM_STR);
            $stmt->bindParam(':contactNo', $data['phone'], PDO::PARAM_STR);
            $stmt->bindParam(':email', $data['email'], PDO::PARAM_STR);
            $stmt->bindParam(':class', $data['class'], PDO::PARAM_STR);
            $stmt->bindParam(':marks', $data['marks'], PDO::PARAM_STR);
            $stmt->bindParam(':enrolldate', $enrolldate, PDO::PARAM_STR);            
            if ($stmt->execute()) { 
                $response['success'] = 1;
                $response["message"] = "Success";
            } else {
                $response['success'] = 0;
                $response["message"] = "Failed";
            }
        } catch (Exception $ex) {
            $response['success'] = 0;
            $response['message'] = $ex->getMessage();
        }       
        return $response;
    }
    function updatestudentdetails($data){
        try {     
            $query = 'UPDATE assignment.tbl_student_master SET studentName = :studentName, fatherName = :fatherName, dob = :dob, address = :address, city = :city, state = :state, pincode = :pincode, contactNo = :contactNo, email = :email, class = :class, marks = :marks WHERE autoId = :studentId';
            $stmt = $this->db->conn_id->prepare($query);
            $stmt->bindParam(':studentName', $data['name'], PDO::PARAM_STR);
            $stmt->bindParam(':fatherName', $data['fname'], PDO::PARAM_STR);            
            $stmt->bindParam(':dob', $data['dob'], PDO::PARAM_STR); 
            $stmt->bindParam(':address', $data['address'], PDO::PARAM_STR);
            $stmt->bindParam(':city', $data['city'], PDO::PARAM_STR);
            $stmt->bindParam(':state', $data['state'], PDO::PARAM_STR);
            $stmt->bindParam(':pincode', $data['pin'], PDO::PARAM_STR);
            $stmt->bindParam(':contactNo', $data['phone'], PDO::PARAM_STR);
            $stmt->bindParam(':email', $data['email'], PDO::PARAM_STR);
            $stmt->bindParam(':class', $data['class'], PDO::PARAM_STR);
            $stmt->bindParam(':marks', $data['marks'], PDO::PARAM_STR);
            $stmt->bindParam(':enrolldate', $data['enrolldate'], PDO::PARAM_STR);  
            $stmt->bindParam(':studentId', $data['studentId'], PDO::PARAM_STR);  

            if ($stmt->execute()) { 
                $response['success'] = 1;
                $response["message"] = "Success";
            } else {
                $response['success'] = 0;
                $response["message"] = "Failed";
            }
        } catch (Exception $ex) {
            $response['success'] = 0;
            $response['message'] = $ex->getMessage();
        }       
        return $response;
    }
}
window.onload = function () {
    
    // date picker initiate
    var date_input = $('input[name="dob"]'); 
    var container = $('.bootstrap-iso form').length > 0 ? $('.bootstrap-iso form').parent() : "body";
    date_input.datepicker({
        format: 'yyyy-mm-dd',
        container: container,
        todayHighlight: true,
        autoclose: true
    });

};


function validateEmail(email) {
    const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}

function phone_validate(phno) 
{ 
  var regexPattern=new RegExp(/^[0-9-+]+$/);    // regular expression pattern
  return regexPattern.test(phno); 
} 


function validate(){        // form validationS
    $('#nameError').html('');
    if($('#name').val()==''){
        $('#nameError').html('Enter Name');
        $('#name').focus();
        return false;
    }
    $('#fnameError').html('');
    if($('#fname').val()==''){
        $('#fnameError').html('Enter father name');
        $('#fname').focus();
        return false;
    }
  

    $('#dobError').html('');
    if($('#dob').val()==''){
        $('#dobError').html('Enter Date Of Birth');
        $('#dob').focus();
        return false;
    }
    $('#addressError').html('');
    if($('#address').val()==''){
        $('#addressError').html('Enter address');
        $('#address').focus();
        return false;
    }

    $('#cityError').html('');
    if($('#city').val()==''){
        $('#cityError').html('Enter city');
        $('#city').focus();
        return false;
    }
    $('#stateError').html('');
    if($('#state').val()==''){
        $('#stateError').html('Enter state');
        $('#state').focus();
        return false;
    }
    $('#pinError').html('');
    if($('#pin').val()==''){
        $('#pinError').html('Enter pin');
        $('#pin').focus();
        return false;
    }
    $('#phoneError').html('');
    if($('#phone').val()==''){
        $('#phoneError').html('Enter phone');
        $('#phone').focus();
        return false;
    }
    var phoneval=$('#phone').val();
    if(!phone_validate(phoneval)){
        $('#phoneError').html('invalid phone');
        $('#phone').focus();
        return false;
    }
   
    $('#emailError').html('');
    if($('#email').val()==''){
        $('#emailError').html('Enter Email');
        $('#email').focus();
        return false;
    }
    $('#emailError').html('');
    if(!validateEmail($('#email').val())){
        $('#emailError').html('Enter Valid Email');
        $('#email').focus();
        return false;
    }

    $('#classError').html('');
    if($('#class').val() ==''){
        $('#classError').html('Enter class');
        $('#class').focus();
        return false;
    } 

    // form submit using ajax
    $.ajax({
        url: $('#base_url').val()+'Web/form_submit',
        type: 'post',
        dataType: 'json',
        data: $('form#user_form').serialize(),
        success: function(json) {
            if(json.success==1){   
                alert(json.message);             
                window.location.href=$('#base_url').val();
            }else{
                alert('some error occured, try again later');
                return;
            }                    
        },
        error: function(e){
            alert('some error occured, try again later');
        }
    });
}
